import logo1 from "./it1.jpg";
import logo20 from "./it2.jfif";
import logo5 from "./it3.jpg";
import logo23 from "./it4.jpg";
import logo4 from "./it5.jpg";
import logo2 from "./it6.jpg";
import logo7 from "./it7.jpg";
import logo6 from "./it8.jpg";
import logo26 from "./it9.jpg";
import logo10 from "./it10.jpg";
import logo11 from "./it11.jpg";
import logo24 from "./it12.jpg";
import logo13 from "./it13.jpg";
import logo15 from "./it14.jpg";
import logo17 from "./it15.jpg";
import logo22 from "./it16.jpg";
import logo18 from "./it17.jpg";
import logo21 from "./it18.jfif";
import logo9 from "./itw19.webp";
import logo25 from "./itw20.webp";
import logo3 from "./itw21.webp";
import logo8 from "./it22.jfif";
import logo19 from "./itw23.webp";
import logo12 from "./it24.jfif";
import logo14 from "./it25.jfif";
import logo16 from "./itw26.webp";

export const members = [
  {
    a: logo1,
  },
  {
    a: logo2,
  },
  {
    a: logo3,
  },
  {
    a: logo4,
  },
  {
    a: logo5,
  },
  {
    a: logo6,
  },
  {
    a: logo7,
  },
  {
    a: logo8,
  },
  {
    a: logo9,
  },
  {
    a: logo10,
  },
  {
    a: logo11,
  },
  {
    a: logo12,
  },
  {
    a: logo13,
  },
  {
    a: logo14,
  },
  {
    a: logo15,
  },
  {
    a: logo16,
  },
  {
    a: logo17,
  },
  {
    a: logo18,
  },
  {
    a: logo19,
  },
  {
    a: logo20,
  },
  {
    a: logo21,
  },
  {
    a: logo22,
  },
  {
    a: logo23,
  },
  {
    a: logo24,
  },
  {
    a: logo25,
  },
  {
    a: logo26,
  },
];
